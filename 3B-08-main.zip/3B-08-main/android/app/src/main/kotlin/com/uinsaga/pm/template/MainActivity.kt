package com.uinsaga.pm.template

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
